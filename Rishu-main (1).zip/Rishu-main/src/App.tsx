import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Stethoscope, Shield, HeartPulse, Activity, PhoneCall, BriefcaseMedical, 
  RefreshCw, UserCheck, Calendar, Clock, User, Mail, Phone, MapPin, 
  Menu, X, ChevronDown, ChevronUp, Star, CheckCircle, MessageSquare, 
  Plus, Search, Share2, ExternalLink, Lock, Award, BookOpen, Heart, 
  Smile, Moon, Sun, ArrowUpRight, HelpCircle, ArrowRight, ShieldCheck,
  Check, FileText, CheckCircle2, ChevronRight
} from 'lucide-react';

// Data and Components
import { CLINIC_INFO, SERVICES, TESTIMONIALS, FAQ_ITEMS } from './data';
import BookingForm from './components/BookingForm';
import HealthBlog from './components/HealthBlog';
import AIAssistant from './components/AIAssistant';

export default function App() {
  const [darkTheme, setDarkTheme] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'about' | 'services' | 'why' | 'testimonials' | 'blogs' | 'faqs'>('about');
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [activeFaq, setActiveFaq] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);
  
  // Custom states for interactive testimonial slider
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  // SEO schema markup creation
  useEffect(() => {
    const schema = {
      "@context": "https://schema.org",
      "@type": "Physician",
      "name": "Dr. S.K. Jain",
      "image": "https://ais-dev-dcj2tf4tcnhibaecs46azr-521659012160.asia-southeast1.run.app/src/assets/images/dr_sk_jain_hero_1780640821075.png",
      "medicalSpecialty": "InternalMedicine",
      "telephone": CLINIC_INFO.receptionPhone,
      "email": CLINIC_INFO.email,
      "address": {
        "@type": "PostalAddress",
        "streetAddress": CLINIC_INFO.address
      },
      "priceRange": "$$",
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          "opens": "09:00",
          "closes": "20:30"
        }
      ]
    };
    
    const scriptId = 'dr-sk-jain-seo-schema';
    let script = document.getElementById(scriptId);
    if (!script) {
      script = document.createElement('script');
      script.id = scriptId;
      script.setAttribute('type', 'application/ld+json');
      script.innerHTML = JSON.stringify(schema);
      document.head.appendChild(script);
    }
  }, []);

  // Monitor scroll for styling headers
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleTheme = () => {
    setDarkTheme(!darkTheme);
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      const offset = 90; // header height
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  // Icon selector helper
  const getIcon = (name: string) => {
    switch (name) {
      case 'Stethoscope': return <Stethoscope size={24} className="text-teal-400" />;
      case 'Shield': return <Shield size={24} className="text-teal-400" />;
      case 'HeartPulse': return <HeartPulse size={24} className="text-teal-400" />;
      case 'Activity': return <Activity size={24} className="text-teal-400" />;
      case 'BriefcaseMedical': return <BriefcaseMedical size={24} className="text-teal-400" />;
      case 'RefreshCw': return <RefreshCw size={24} className="text-teal-400" />;
      case 'UserCheck': return <UserCheck size={24} className="text-teal-400" />;
      case 'PhoneCall': return <PhoneCall size={24} className="text-teal-400" />;
      default: return <Stethoscope size={24} className="text-teal-400" />;
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 font-sans ${
      darkTheme ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'
    } selection:bg-teal-500 selection:text-white`}>

      {/* STICKY QUICK APPOINTMENT BAR */}
      <div className="fixed bottom-6 left-6 z-40 select-none">
        <motion.button
          onClick={() => scrollToSection('booking')}
          id="sticky-booking-pill"
          className="flex items-center gap-2 px-5 py-4 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded-full shadow-2xl cursor-pointer hover:shadow-teal-500/20 active:translate-y-0.5 transition-all duration-300 text-xs tracking-wider uppercase border border-white/10"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Calendar size={16} />
          <span>Book Priority Appt</span>
        </motion.button>
      </div>

      {/* FLOAT WHATSAPP APPLIANCE */}
      <a 
        href={`https://wa.me/${CLINIC_INFO.whatsappNumber.replace(/[+\s]/g, '')}?text=Hello%20Dr.%20S.K.%20Jain%20Healthcare%20Concierge,%20I'd%20like%20to%20inquire%20about%20a%20clinical%20consultation.`}
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 left-52 sm:left-auto sm:right-56 z-40 flex items-center gap-2 px-5 py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-full shadow-2xl cursor-pointer hover:shadow-emerald-500/20 active:translate-y-0.5 transition-all duration-300 border border-white/10 text-xs tracking-wider uppercase"
        title="Direct Line on WhatsApp"
        id="floating-whatsapp-direct"
      >
        <Phone size={16} />
        <span>WhatsApp Clinic</span>
      </a>

      {/* MOUNT FLOATING DEEP AI CHATBOT */}
      <AIAssistant darkTheme={darkTheme} />

      {/* SECTION HEADER / NAVIGATION */}
      <header className={`sticky top-0 z-50 transition-all duration-300 border-b select-none ${
        scrolled 
          ? darkTheme 
            ? 'bg-slate-950/90 backdrop-blur-md border-slate-800' 
            : 'bg-white/90 backdrop-blur-md border-slate-100 shadow-xs'
          : 'bg-transparent border-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo Brand */}
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => scrollToSection('hero')}>
            <div className="h-10 w-10 rounded-xl bg-gradient-to-r from-teal-500 to-indigo-600 text-white flex items-center justify-center font-extrabold text-lg shadow-md md:rotate-3 hover:rotate-0 transition-transform">
              SJ
            </div>
            <div>
              <span className={`text-base font-extrabold tracking-tight font-sans leading-none block ${
                darkTheme ? 'text-white' : 'text-slate-950'
              }`}>
                DR. S.K. JAIN
              </span>
              <span className="text-[9px] font-bold text-teal-400 font-mono tracking-widest uppercase block mt-1">
                PLATINUM EXECUTIVE HEALTHCARE
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-xs font-semibold uppercase tracking-wider">
            <button onClick={() => scrollToSection('about')} className={`cursor-pointer transition-colors ${darkTheme ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>About Doctor</button>
            <button onClick={() => scrollToSection('services')} className={`cursor-pointer transition-colors ${darkTheme ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>Services</button>
            <button onClick={() => scrollToSection('why-us')} className={`cursor-pointer transition-colors ${darkTheme ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>Why Choose Us</button>
            <button onClick={() => scrollToSection('testimonials')} className={`cursor-pointer transition-colors ${darkTheme ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>Reviews</button>
            <button onClick={() => scrollToSection('blogs')} className={`cursor-pointer transition-colors ${darkTheme ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>Medical Blog</button>
            <button onClick={() => scrollToSection('faqs')} className={`cursor-pointer transition-colors ${darkTheme ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>FAQs</button>
            <button onClick={() => scrollToSection('info')} className={`cursor-pointer transition-colors ${darkTheme ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}>Clinic Location</button>
          </nav>

          {/* Right Core Actions */}
          <div className="hidden sm:flex items-center gap-4">
            
            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme} 
              className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                darkTheme ? 'border-slate-800 hover:bg-slate-950 text-amber-400' : 'border-slate-200 hover:bg-slate-100 text-indigo-700'
              }`}
              title={darkTheme ? "Switch to Light Clinical Theme" : "Switch to Dark Executive Theme"}
            >
              {darkTheme ? <Sun size={17} /> : <Moon size={17} />}
            </button>

            {/* Direct Dial Header */}
            <a 
              href={`tel:${CLINIC_INFO.receptionPhone}`}
              className={`text-xs font-bold font-mono tracking-wide hidden xl:flex items-center gap-2 px-3 py-1.5 border border-dashed rounded-lg ${
                darkTheme ? 'border-indigo-500/20 text-indigo-400' : 'border-indigo-600/25 text-indigo-700'
              }`}
            >
              <PhoneCall size={13} className="animate-bounce" />
              {CLINIC_INFO.receptionPhone}
            </a>

            {/* CTA Head button */}
            <button 
              onClick={() => scrollToSection('booking')}
              className="px-5 py-2.5 bg-gradient-to-r from-teal-600 to-indigo-700 hover:from-teal-500 hover:to-indigo-600 text-white font-bold text-xs rounded-xl shadow-lg transition-all duration-300 cursor-pointer active:translate-y-0.5 uppercase tracking-wider"
            >
              Book Appointment
            </button>
          </div>

          {/* Quick Mobile trigger bar */}
          <div className="flex sm:hidden items-center gap-2">
            <button 
              onClick={toggleTheme} 
              className={`p-2 rounded-lg border cursor-pointer ${
                darkTheme ? 'border-slate-800 text-amber-400' : 'border-slate-200 text-indigo-700'
              }`}
            >
              {darkTheme ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-2 rounded-lg cursor-pointer ${
                darkTheme ? 'text-slate-300' : 'text-slate-800'
              }`}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

        </div>
      </header>

      {/* MOBILE TRIGGER VIEW */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`fixed top-20 inset-x-0 z-40 border-b lg:hidden select-none outline-hidden ${
              darkTheme ? 'bg-slate-950/95 border-slate-800' : 'bg-white/95 border-slate-100 shadow-xl'
            }`}
          >
            <div className="px-6 py-6 space-y-4">
              <div className="flex flex-col gap-3 font-semibold text-sm">
                <button onClick={() => scrollToSection('about')} className={`text-left py-2 border-b cursor-pointer ${darkTheme ? 'border-slate-900 text-slate-300' : 'border-slate-100 text-slate-700'}`}>About Doctor</button>
                <button onClick={() => scrollToSection('services')} className={`text-left py-2 border-b cursor-pointer ${darkTheme ? 'border-slate-900 text-slate-300' : 'border-slate-100 text-slate-700'}`}>Services & Diagnostic Specialties</button>
                <button onClick={() => scrollToSection('why-us')} className={`text-left py-2 border-b cursor-pointer ${darkTheme ? 'border-slate-900 text-slate-300' : 'border-slate-100 text-slate-700'}`}>Why Choose Us</button>
                <button onClick={() => scrollToSection('testimonials')} className={`text-left py-2 border-b cursor-pointer ${darkTheme ? 'border-slate-900 text-slate-300' : 'border-slate-100 text-slate-700'}`}>Patient Testimonials</button>
                <button onClick={() => scrollToSection('blogs')} className={`text-left py-2 border-b cursor-pointer ${darkTheme ? 'border-slate-900 text-slate-300' : 'border-slate-100 text-slate-700'}`}>Medical Research Blog</button>
                <button onClick={() => scrollToSection('faqs')} className={`text-left py-2 border-b cursor-pointer ${darkTheme ? 'border-slate-900 text-slate-300' : 'border-slate-100 text-slate-700'}`}>FAQs</button>
                <button onClick={() => scrollToSection('info')} className={`text-left py-2 cursor-pointer ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>Coordinates & Schedule</button>
              </div>

              <div className="pt-4 flex flex-col gap-3 select-none">
                <a 
                  href={`tel:${CLINIC_INFO.receptionPhone}`}
                  className={`w-full py-3 border border-dashed rounded-xl flex items-center justify-center gap-2 font-mono text-xs font-bold ${
                    darkTheme ? 'border-slate-800 text-teal-400' : 'border-slate-200 text-teal-800'
                  }`}
                >
                  <PhoneCall size={14} />
                  Reception: {CLINIC_INFO.receptionPhone}
                </a>
                <button 
                  onClick={() => scrollToSection('booking')}
                  className="w-full py-3.5 bg-gradient-to-r from-teal-600 to-indigo-700 hover:from-teal-500 hover:to-indigo-600 text-white text-xs font-bold tracking-widest uppercase rounded-xl transition-all cursor-pointer shadow-lg text-center"
                >
                  Book Instant Appointment
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ULTRA-PREMIUM HERO SECTION */}
      <section id="hero" className="relative min-h-[90vh] flex items-center overflow-hidden py-16 lg:py-24">
        
        {/* Futuristic Background Accents */}
        <div className="absolute inset-0 z-0 pointer-events-none select-none">
          <div className="absolute top-[20%] left-[10%] w-[350px] h-[350px] rounded-full bg-teal-500/10 blur-[120px]" />
          <div className="absolute bottom-[10%] right-[10%] w-[400px] h-[400px] rounded-full bg-indigo-500/10 blur-[140px]" />
          {/* Gridded overlay pattern */}
          <div className={`absolute inset-0 opacity-[0.03] ${darkTheme ? 'bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:30px_30px]' : 'bg-[linear-gradient(to_right,#000_1px,transparent_1px),linear-gradient(to_bottom,#000_1px,transparent_1px)] bg-[size:30px_30px]'}`} />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Hero Left Content Column */}
            <div className="lg:col-span-7 space-y-6 lg:space-y-8 select-text">
              
              <div className="space-y-4">
                {/* Board Certification Badge */}
                <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-[10px] font-extrabold uppercase tracking-widest border ${
                  darkTheme 
                    ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400 shadow-inner' 
                    : 'bg-indigo-50 border-indigo-100 text-indigo-800'
                }`}>
                  <ShieldCheck size={14} /> EX-AIIMS SCHOLAR • SENIOR CLINICAL DIAGNOSTICIAN
                </span>

                <h1 className={`text-4xl sm:text-5xl lg:text-5.5xl font-extrabold tracking-tight leading-[110%] ${
                  darkTheme ? 'text-white' : 'text-slate-950 font-sans'
                }`}>
                  Dr. S.K. Jain – <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-indigo-500">
                    Excellence
                  </span> in Healthcare, <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-teal-400">
                    Compassion
                  </span> in Care.
                </h1>

                <p className={`text-sm sm:text-base leading-relaxed max-w-xl ${
                  darkTheme ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  A premium lifespan diagnostic paradigm focusing on molecular arterial tracing, preventative metabolic stabilization, and comprehensive physiological care. Merging Cleveland-class scientific rigor with Silicon Valley virtual clinical agility.
                </p>
              </div>

              {/* Trust Indicators Cards Grid */}
              <div className="grid grid-cols-2 gap-4 max-w-lg">
                <div className={`p-4 rounded-2xl border ${darkTheme ? 'bg-slate-950/40 border-slate-800' : 'bg-white border-slate-100 shadow-xs'}`}>
                  <p className="text-xs font-bold text-teal-400 mb-1">✓ 24+ YEARS</p>
                  <p className={`text-[11px] font-medium ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>Of Elite Clinical Experience</p>
                </div>
                <div className={`p-4 rounded-2xl border ${darkTheme ? 'bg-slate-950/40 border-slate-800' : 'bg-white border-slate-100 shadow-xs'}`}>
                  <p className="text-xs font-bold text-teal-400 mb-1">✓ 15,000+ PATIENTS</p>
                  <p className={`text-[11px] font-medium ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>Diagnosed & Managed Globally</p>
                </div>
                <div className={`p-4 rounded-2xl border ${darkTheme ? 'bg-slate-950/40 border-slate-800' : 'bg-white border-slate-100 shadow-xs'}`}>
                  <p className="text-xs font-bold text-teal-400 mb-1">✓ APPOINTED PANEL</p>
                  <p className={`text-[11px] font-medium ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>Trusted Healthcare Professional</p>
                </div>
                <div className={`p-4 rounded-2xl border ${darkTheme ? 'bg-slate-950/40 border-slate-800' : 'bg-white border-slate-100 shadow-xs'}`}>
                  <p className="text-xs font-bold text-teal-400 mb-1">✓ ADVANCED LABS</p>
                  <p className={`text-[11px] font-medium ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>Modern Biotech-Driven Diagnostics</p>
                </div>
              </div>

              {/* CTA Action Buttons Group */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2 select-none">
                <button 
                  onClick={() => scrollToSection('booking')}
                  className="px-8 py-4 bg-teal-600 hover:bg-teal-500 text-white font-bold text-sm rounded-xl cursor-pointer shadow-lg hover:shadow-teal-900/10 text-center active:translate-y-0.5 transition-all flex items-center justify-center gap-2"
                >
                  Book Secure Appointment
                  <ArrowRight size={16} />
                </button>
                <button 
                  onClick={() => scrollToSection('info')}
                  className={`px-8 py-4 rounded-xl font-bold text-sm text-center border cursor-pointer active:translate-y-0.5 transition-all ${
                    darkTheme 
                      ? 'border-slate-800 hover:bg-slate-900 text-slate-300 hover:text-white' 
                      : 'border-slate-200 hover:bg-slate-100 text-slate-700 hover:text-slate-950'
                  }`}
                >
                  Find Office Locations
                </button>
              </div>

            </div>

            {/* Hero Right Column - Image Appliance */}
            <div className="lg:col-span-5 relative flex justify-center items-center select-none">
              
              {/* Backglow panel */}
              <div className="absolute inset-0 bg-gradient-to-tr from-teal-500/10 via-indigo-600/10 to-transparent blur-[80px]" />
              
              {/* Image Border frame */}
              <div className="relative p-2.5 rounded-[44px] bg-gradient-to-tr from-teal-500/30 to-indigo-500/20 overflow-hidden shadow-2xl">
                <div className={`rounded-[34px] overflow-hidden border ${darkTheme ? 'border-slate-800 bg-slate-950' : 'border-slate-100 bg-white'}`}>
                  <img
                    src="/src/assets/images/dr_sk_jain_hero_1780640821075.png"
                    alt="Dr. S.K. Jain Portrait"
                    referrerPolicy="no-referrer"
                    className="w-full max-w-[380px] lg:max-w-none h-auto object-cover h-[450px] hover:scale-103 transition-transform duration-500"
                  />
                </div>

                {/* Overlaid Clinician Tag Card */}
                <div className={`absolute bottom-6 -right-2 p-4 rounded-2xl border flex items-center gap-3 shadow-2xl select-text mr-6 ${
                  darkTheme ? 'bg-slate-950/90 border-slate-800 text-white' : 'bg-white/95 border-slate-100 text-slate-800'
                }`}>
                  <div className="h-8 w-8 rounded-lg bg-teal-500/10 text-teal-400 flex items-center justify-center">
                    <Award size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] font-extrabold uppercase tracking-widest text-teal-500">Board Director</p>
                    <p className="text-xs font-bold leading-none mt-1">Delhi Medical Council</p>
                  </div>
                </div>

                {/* Interactive Telehealth Active Sign */}
                <div className="absolute top-6 left-6 p-2 rounded-xl bg-slate-950/80 backdrop-blur-md border border-white/10 flex items-center gap-2 text-[10px] font-semibold text-white shadow-2xl select-none">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                  TELEHEALTH SLOTS ACTIVE
                </div>

              </div>

            </div>

          </div>
        </div>
      </section>

      {/* METRIC RIBBON */}
      <section className={`py-8 border-y select-none ${darkTheme ? 'bg-slate-950/40 border-slate-900' : 'bg-slate-50 border-slate-150'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <p className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-indigo-400">15,000+</p>
              <p className={`text-[10px] uppercase font-bold tracking-widest mt-1.5 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>Patients Healed</p>
            </div>
            <div>
              <p className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-indigo-400">24+ Years</p>
              <p className={`text-[10px] uppercase font-bold tracking-widest mt-1.5 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>Clinical Tenure</p>
            </div>
            <div>
              <p className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-indigo-400">4.9 / 5.0</p>
              <p className={`text-[10px] uppercase font-bold tracking-widest mt-1.5 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>Verified Reviews</p>
            </div>
            <div>
              <p className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-indigo-400">98.7%</p>
              <p className={`text-[10px] uppercase font-bold tracking-widest mt-1.5 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>Diagnostic Precision</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION: ABOUT DR. S.K. JAIN */}
      <section id="about" className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            
            {/* Left intro text & Timeline (8 cols) */}
            <div className="lg:col-span-7 space-y-12">
              <div className="space-y-4 select-text">
                <span className="text-xs font-bold uppercase tracking-widest text-teal-500 font-mono">Biography Profile</span>
                <h2 className={`text-3xl md:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                  Excellence Rooted in Science & Academic Authority
                </h2>
                <p className={`text-xs sm:text-sm leading-relaxed ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                  Dr. S.K. Jain is a internationally recognized consultant diagnostic physician with over two decades of clinical tenure across prominent hospitals, including a prestigious teaching residency track at the **All India Institute of Medical Sciences (AIIMS)**, New Delhi.
                </p>
                <p className={`text-xs sm:text-sm leading-relaxed ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                  His clinical practice shifts medicine from passive symptom monitoring to comprehensive systemic prevention. By integrating deep biomarker analyses (ApoB, metabolic glucose curves, endocrine maps) with patient habit design, Dr. Jain stabilizes health indicators with maximum speed and security.
                </p>
              </div>

              {/* TIMELINE DESIGN */}
              <div className="space-y-6">
                <h3 className={`text-base font-extrabold tracking-tight uppercase tracking-wider ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                  Professional Milestones & Impact History
                </h3>
                
                {/* Custom timeline track */}
                <div className="relative border-l border-slate-700/50 pl-6 ml-3 space-y-8 select-text">
                  
                  {/* Item 1 */}
                  <div className="relative">
                    <span className="absolute -left-[31px] top-1.5 h-4.5 w-4.5 rounded-full bg-teal-500 border-4 border-slate-950 flex items-center justify-center" />
                    <div>
                      <span className="text-[10px] font-extrabold text-teal-400 font-mono">2014 – Present</span>
                      <h4 className={`text-sm font-bold ${darkTheme ? 'text-white' : 'text-slate-900'}`}>Director & Chief Diagnostician</h4>
                      <p className={`text-[11px] font-medium leading-relaxed mt-1 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                        Platinum Preventative Enclave & Longevity Analytics, overseeing high-priority health screening protocols and metabolic therapeutics.
                      </p>
                    </div>
                  </div>

                  {/* Item 2 */}
                  <div className="relative">
                    <span className="absolute -left-[31px] top-1.5 h-4.5 w-4.5 rounded-full bg-teal-500 border-4 border-slate-950 flex items-center justify-center" />
                    <div>
                      <span className="text-[10px] font-extrabold text-teal-400 font-mono">2007 – 2014</span>
                      <h4 className={`text-sm font-bold ${darkTheme ? 'text-white' : 'text-slate-900'}`}>Vice Chief Fellow in Cardiology Care Audit</h4>
                      <p className={`text-[11px] font-medium leading-relaxed mt-1 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                        Apollo Medical Center, managing complex multi-disciplinary ICU admissions, arterial decalcification pathways, and second opinion boards.
                      </p>
                    </div>
                  </div>

                  {/* Item 3 */}
                  <div className="relative">
                    <span className="absolute -left-[31px] top-1.5 h-4.5 w-4.5 rounded-full bg-teal-500 border-4 border-slate-950 flex items-center justify-center" />
                    <div>
                      <span className="text-[10px] font-extrabold text-teal-400 font-mono">2002 – 2007</span>
                      <h4 className={`text-sm font-bold ${darkTheme ? 'text-white' : 'text-slate-900'}`}>Clinical Resident (Internal Medicine)</h4>
                      <p className={`text-[11px] font-medium leading-relaxed mt-1 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                        All India Institute of Medical Sciences (AIIMS), New Delhi, completing intensive medical research and academic diagnosis protocols.
                      </p>
                    </div>
                  </div>

                </div>
              </div>

            </div>

            {/* Right Academic Stats & Goals (5 cols) */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Credentials / Degrees Card */}
              <div className={`p-6 rounded-3xl border ${darkTheme ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-100 shadow-md'} space-y-4`}>
                <h3 className={`text-sm font-extrabold uppercase tracking-widest ${darkTheme ? 'text-teal-400' : 'text-teal-700'}`}>
                  Clinical Accreditation
                </h3>
                <div className="space-y-3.5 select-text">
                  <div className="flex items-start gap-3">
                    <div className="p-1 rounded-md bg-teal-500/10 text-teal-400 mt-0.5"><Check size={14} /></div>
                    <div>
                      <p className={`text-xs font-bold ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Master of Medicine (M.D.)</p>
                      <p className="text-[10px] text-slate-400 font-medium">All India Institute of Medical Sciences (AIIMS), MD in Internal Medicine</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-1 rounded-md bg-teal-500/10 text-teal-400 mt-0.5"><Check size={14} /></div>
                    <div>
                      <p className={`text-xs font-bold ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Bachelor of Medicine & Surgery (M.B.B.S.)</p>
                      <p className="text-[10px] text-slate-400 font-medium">Prestigious Med-University Honors Graduate</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-1 rounded-md bg-teal-500/10 text-teal-400 mt-0.5"><Check size={14} /></div>
                    <div>
                      <p className={`text-xs font-bold ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Diplomat of lifespan Science Registry</p>
                      <p className="text-[10px] text-slate-400 font-medium">Member of International Association of Longevity Medicine</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-1 rounded-md bg-teal-500/10 text-teal-400 mt-0.5"><Check size={14} /></div>
                    <div>
                      <p className={`text-xs font-bold ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Board Fellow of Delhi Med-Council</p>
                      <p className="text-[10px] text-slate-400 font-medium">Active clinical standards committee counselor registry</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Mission / Vision Bento Card */}
              <div className="grid grid-cols-1 gap-4">
                
                {/* Mission */}
                <div className={`p-5 rounded-3xl border ${darkTheme ? 'bg-slate-900/30 border-slate-800/80' : 'bg-slate-100/50 border-slate-200/50'} space-y-2`}>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 font-mono">Our Healthcare Mission</p>
                  <p className={`text-xs leading-relaxed ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                    To shift the treatment vector from late-stage crisis management into early, predictive biological audits, ensuring every patient preserves their ultimate arterial, cardiac, and cognitive lifespan.
                  </p>
                </div>

                {/* Vision */}
                <div className={`p-5 rounded-3xl border ${darkTheme ? 'bg-slate-900/30 border-slate-800/80' : 'bg-slate-100/50 border-slate-200/50'} space-y-2`}>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 font-mono">Clinical Vision</p>
                  <p className={`text-xs leading-relaxed ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                    To build a premium, digital-first healthcare platform standard across India where patient diagnostics are continuously updated, preventing disease spikes dynamically with zero clinical friction.
                  </p>
                </div>

              </div>

            </div>

          </div>
        </div>
      </section>

      {/* SECTION: SERVICES & SPECIALTIES */}
      <section id="services" className={`py-20 lg:py-28 border-y ${darkTheme ? 'bg-slate-900/10 border-slate-900' : 'bg-slate-50 border-slate-200/40'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16 select-text">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-400 font-mono">Clinical Specialty Catalog</span>
            <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
              High-Precision Diagnostic & Preventive Services
            </h2>
            <p className={`text-xs sm:text-sm ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>
              Each specialty is calibrated around meticulous biometric auditing, continuous telemetry care profiles, and gold-standard treatment formulations. Select a card to view strategic medical insights.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {SERVICES.map((srv) => (
              <motion.div
                key={srv.id}
                layoutId={`srv-${srv.id}`}
                onClick={() => setSelectedService(selectedService === srv.id ? null : srv.id)}
                className={`p-6 rounded-3xl border flex flex-col justify-between transition-all duration-300 cursor-pointer ${
                  selectedService === srv.id
                    ? darkTheme 
                      ? 'bg-gradient-to-b from-indigo-950 to-slate-900 border-teal-500 scale-[1.01]' 
                      : 'bg-gradient-to-b from-teal-50 to-white border-teal-500 shadow-md scale-[1.01]'
                    : darkTheme
                      ? 'bg-slate-900/50 border-slate-800/85 hover:border-slate-700/80 hover:bg-slate-900'
                      : 'bg-white border-slate-100 hover:border-slate-200 shadow-xs'
                }`}
                whileHover={{ y: -3 }}
                transition={{ duration: 0.2 }}
                id={`srv-idx-${srv.id}`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="p-3 bg-teal-500/10 rounded-2xl border border-teal-500/20 text-teal-400">
                      {getIcon(srv.iconName)}
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase font-mono tracking-widest">
                      {selectedService === srv.id ? "Minimize" : "Details"}
                    </span>
                  </div>

                  <h3 className={`text-sm md:text-base font-bold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                    {srv.title}
                  </h3>

                  <p className={`text-[11px] leading-relaxed line-clamp-3 ${darkTheme ? 'text-slate-300' : 'text-slate-500'}`}>
                    {srv.description}
                  </p>

                  <AnimatePresence>
                    {selectedService === srv.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="pt-4 mt-4 border-t border-slate-700/20 space-y-4 text-[11px]"
                      >
                        <p className={`leading-relaxed font-sans ${darkTheme ? 'text-slate-200' : 'text-slate-700'}`}>
                          {srv.detailedDescription}
                        </p>
                        <div className="space-y-1.5 select-text">
                          <p className="font-extrabold uppercase text-[9px] tracking-widest text-teal-400 font-mono">Diagnostic Deliverables:</p>
                          {srv.benefits.map((benefit, bidx) => (
                            <div key={bidx} className="flex items-center gap-1.5 text-slate-400">
                              <CheckCircle size={10} className="text-teal-400 shrink-0" />
                              <span className={darkTheme ? 'text-slate-300' : 'text-slate-600'}>{benefit}</span>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="mt-6 pt-3 border-t border-slate-700/10 flex items-center justify-between text-[11px] font-bold text-teal-400">
                  <span>Explore Protocol</span>
                  <Plus size={14} className={`transform transition-transform ${selectedService === srv.id ? 'rotate-45 text-amber-500' : ''}`} />
                </div>

              </motion.div>
            ))}
          </div>

          {/* Virtual consultation alert ribbon */}
          <div className={`mt-12 p-6 rounded-3xl border text-center ${
            darkTheme ? 'bg-indigo-950/20 border-indigo-500/15' : 'bg-indigo-50/50 border-indigo-100'
          }`}>
            <p className="text-xs sm:text-sm font-semibold">
              🤔 Have questions about complex chronic care or specialized metabolic profiling? Let our AI Concierge triage your details. Click the <strong className="text-teal-400 cursor-pointer" onClick={() => {
                const el = document.getElementById('ai-concierge-trigger');
                if (el) el.click();
              }}>AI Clinical Assistant</strong> floating badge in the bottom-right corner.
            </p>
          </div>

        </div>
      </section>

      {/* SECTION: WHY CHOOSE DR. S.K. JAIN */}
      <section id="why-us" className="py-20 lg:py-28 select-text">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* Why-Us Left Description Box */}
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-bold uppercase tracking-widest text-teal-400 font-mono">Unrivaled Clinical Advantages</span>
              <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                Redefining the Patient Experience with Digital Precision
              </h2>
              <p className={`text-xs sm:text-sm leading-relaxed ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                Typical clinics treat illness at the point of fracture. At Dr. S.K. Jain's medical registry, we evaluate the baseline systems of the human body. By measuring risk metrics continuously, we build absolute resistance against chronic decay.
              </p>

              {/* Animated feature list */}
              <div className="space-y-4">
                
                {/* Advantage 1 */}
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center shrink-0 border border-teal-500/20 mt-1">
                    <UserCheck size={18} />
                  </div>
                  <div>
                    <h4 className={`text-sm font-bold ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Empathetic, Personalized Diagnostics</h4>
                    <p className={`text-[11px] leading-relaxed mt-0.5 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                      We limit in-clinic consultation patient volumes to spend a dedicated 30 minutes mapping your complete physiology, lifestyle stressors, and medical goals.
                    </p>
                  </div>
                </div>

                {/* Advantage 2 */}
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center shrink-0 border border-indigo-500/20 mt-1">
                    <Activity size={18} />
                  </div>
                  <div>
                    <h4 className={`text-sm font-bold ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Vitals Telemetry & Continuous Syncing</h4>
                    <p className={`text-[11px] leading-relaxed mt-0.5 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                      Registered patients are outfitted with secure electronic tracking logs. We keep tabs on continuous glycemic trends and blood pressure spike parameters weekly.
                    </p>
                  </div>
                </div>

                {/* Advantage 3 */}
                <div className="flex gap-4">
                  <div className="h-10 w-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center shrink-0 border border-teal-500/20 mt-1">
                    <Award size={18} />
                  </div>
                  <div>
                    <h4 className={`text-sm font-bold ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Affordable Excellence, Cashless Convenience</h4>
                    <p className={`text-[11px] leading-relaxed mt-0.5 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                      World-class diagnostic pathways matched with highly transparent pricing (consultations starting at INR 1,200) and smooth cashless coordination.
                    </p>
                  </div>
                </div>

              </div>

            </div>

            {/* Why-Us Right Active Counters & Proof Cards */}
            <div className="lg:col-span-6 relative select-none">
              <div className="absolute inset-0 bg-gradient-to-tr from-teal-500/5 to-indigo-600/5 blur-[100px]" />
              
              <div className="grid grid-cols-2 gap-4">
                
                {/* Active Metric Card 1 */}
                <div className={`p-6 rounded-3xl border ${darkTheme ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-100 shadow-sm'} flex flex-col justify-between h-44`}>
                  <div className="h-10 w-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                    <Heart size={20} />
                  </div>
                  <div>
                    <p className="text-3xl font-extrabold text-white">99.8%</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase mt-1 tracking-wider">Clinical Clean Record</p>
                    <span className="text-[9px] text-teal-400 font-mono">Zero surgical defaults</span>
                  </div>
                </div>

                {/* Active Metric Card 2 */}
                <div className={`p-6 rounded-3xl border ${darkTheme ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-100 shadow-sm'} flex flex-col justify-between h-44`}>
                  <div className="h-10 w-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                    <Award size={20} />
                  </div>
                  <div>
                    <p className="text-3xl font-extrabold text-white">25+</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase mt-1 tracking-wider">Peer Essay Publications</p>
                    <span className="text-[9px] text-indigo-400 font-mono">Delhi Cardiology Board</span>
                  </div>
                </div>

                {/* Active Metric Card 3 */}
                <div className={`p-6 rounded-3xl border ${darkTheme ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-100 shadow-sm'} flex flex-col justify-between h-44`}>
                  <div className="h-10 w-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                    <UserCheck size={20} />
                  </div>
                  <div>
                    <p className="text-3xl font-extrabold text-white">30 Min</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase mt-1 tracking-wider">Dedicated Slot Tenure</p>
                    <span className="text-[9px] text-indigo-400 font-mono">Acutely thorough analysis</span>
                  </div>
                </div>

                {/* Active Metric Card 4 */}
                <div className={`p-6 rounded-3xl border ${darkTheme ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-100 shadow-sm'} flex flex-col justify-between h-44`}>
                  <div className="h-10 w-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                    <RefreshCw size={20} />
                  </div>
                  <div>
                    <p className="text-3xl font-extrabold text-white">24/7</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase mt-1 tracking-wider">Continuity Portal Access</p>
                    <span className="text-[9px] text-teal-400 font-mono">Immediate remote advice</span>
                  </div>
                </div>

              </div>

            </div>

          </div>
        </div>
      </section>

      {/* SECTION: PATIENT TESTIMONIALS */}
      <section id="testimonials" className={`py-20 lg:py-28 border-y select-text ${darkTheme ? 'bg-slate-900/10 border-slate-900' : 'bg-slate-50 border-slate-200/50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <span className="text-xs font-bold uppercase tracking-widest text-indigo-400 font-mono">Verified Diagnostics Records</span>
            <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
              Trust Earned Through Life-Changing Results
            </h2>
            <p className={`text-xs sm:text-sm ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>
              Review certified case feedback from patients who reversed severe glycemics and stabilized chronic syndromes under Dr. S.K. Jain's precision regimens.
            </p>
          </div>

          {/* Luxury Sliding Review Box */}
          <div className="max-w-4xl mx-auto relative select-none">
            
            {/* Nav Arrows */}
            <div className="absolute top-1/2 -translate-y-1/2 -left-4 sm:-left-12 z-10 shrink-0">
              <button 
                onClick={() => setTestimonialIdx(prev => prev === 0 ? TESTIMONIALS.length - 1 : prev - 1)}
                className={`p-2.5 rounded-full border cursor-pointer hover:scale-105 active:scale-95 transition-all ${
                  darkTheme ? 'border-slate-800 bg-slate-950 text-white hover:bg-slate-900' : 'border-slate-200 bg-white text-slate-800 hover:bg-slate-50'
                }`}
                title="Previous testimonial"
              >
                <ChevronRight size={18} className="rotate-180" />
              </button>
            </div>

            <div className="absolute top-1/2 -translate-y-1/2 -right-4 sm:-right-12 z-10 shrink-0">
              <button 
                onClick={() => setTestimonialIdx(prev => prev === TESTIMONIALS.length - 1 ? 0 : prev + 1)}
                className={`p-2.5 rounded-full border cursor-pointer hover:scale-105 active:scale-95 transition-all ${
                  darkTheme ? 'border-slate-800 bg-slate-950 text-white hover:bg-slate-900' : 'border-slate-200 bg-white text-slate-800 hover:bg-slate-50'
                }`}
                title="Next testimonial"
              >
                <ChevronRight size={18} />
              </button>
            </div>

            {/* Main Active Testimonial */}
            <AnimatePresence mode="wait">
              <motion.div
                key={TESTIMONIALS[testimonialIdx].id}
                initial={{ opacity: 0, x: 25 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -25 }}
                transition={{ duration: 0.3 }}
                className={`p-8 md:p-12 rounded-3xl border ${
                  darkTheme ? 'bg-gradient-to-tr from-slate-900 via-slate-950 to-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-xl'
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                  
                  {/* Avatar and Info */}
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-teal-500/10 text-teal-400 font-extrabold text-sm flex items-center justify-center border border-teal-500/20 shadow-md uppercase select-none">
                      {TESTIMONIALS[testimonialIdx].avatarSeed.substring(0,2)}
                    </div>
                    <div>
                      <h4 className={`text-sm md:text-base font-bold leading-none ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                        {TESTIMONIALS[testimonialIdx].name}
                      </h4>
                      <p className="text-[10px] text-teal-400 font-mono tracking-wider mt-1.5 font-bold uppercase">
                        Diagnosed: {TESTIMONIALS[testimonialIdx].condition}
                      </p>
                    </div>
                  </div>

                  {/* Rating parameters */}
                  <div className="flex items-center gap-1 shrink-0">
                    {[...Array(TESTIMONIALS[testimonialIdx].rating)].map((_, i) => (
                      <Star key={i} size={13} className="fill-amber-400 text-amber-400" />
                    ))}
                    <span className="text-[10px] font-bold text-slate-500 ml-1.5 font-mono select-none">Verified Record</span>
                  </div>

                </div>

                <p className={`text-xs md:text-sm leading-relaxed italic ${darkTheme ? 'text-slate-200' : 'text-slate-600'}`}>
                  "{TESTIMONIALS[testimonialIdx].review}"
                </p>

                <div className="mt-6 pt-4 border-t border-slate-700/10 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                  <span>Admit Date: {TESTIMONIALS[testimonialIdx].date}</span>
                  <span className="inline-flex items-center gap-1.5 font-bold text-emerald-400">
                    <CheckCircle size={11} /> Fully Verified Outcome
                  </span>
                </div>

              </motion.div>
            </AnimatePresence>

            {/* Slider visual dots indicators */}
            <div className="flex justify-center items-center gap-2 mt-6 select-none shrink-0">
              {TESTIMONIALS.map((t, idx) => (
                <button
                  key={t.id}
                  onClick={() => setTestimonialIdx(idx)}
                  className={`h-2.5 rounded-full cursor-pointer transition-all ${
                    testimonialIdx === idx ? 'w-6 bg-teal-500' : 'w-2.5 bg-slate-700/50'
                  }`}
                  title={`Go to testimonial ${idx + 1}`}
                />
              ))}
            </div>

          </div>

          {/* Google Med-Reviews Verification Badge */}
          <div className="text-center mt-12 select-none select-text">
            <p className="text-[10px] uppercase font-bold tracking-widest text-slate-500">Google Business Verified Registry Rating</p>
            <div className="flex items-center justify-center gap-2 mt-2">
              <span className="text-lg font-bold">4.9 Star</span>
              <div className="flex text-amber-400"><Star size={16} className="fill-current" /><Star size={16} className="fill-current" /><Star size={16} className="fill-current" /><Star size={16} className="fill-current" /><Star size={16} className="fill-current" /></div>
              <span className="text-xs text-slate-400 font-semibold">(Based on 480+ digital patient ratings)</span>
            </div>
          </div>

        </div>
      </section>

      {/* SECTION: SECURE CLINICAL APPOINTMENT BOOKING */}
      <section id="booking" className="py-20 lg:py-28 relative">
        <div className="absolute inset-0 z-0 pointer-events-none select-none">
          <div className="absolute top-[30%] right-[5%] w-[350px] h-[350px] rounded-full bg-teal-500/5 blur-[120px]" />
          <div className="absolute bottom-[20%] left-[5%] w-[300px] h-[300px] rounded-full bg-indigo-500/5 blur-[105px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* Booking Text Copy Info Left column */}
            <div className="lg:col-span-5 space-y-6 lg:space-y-8 select-text">
              <span className="text-xs font-bold uppercase tracking-widest text-teal-400 font-mono">Premium Consultation Booking</span>
              <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                Secure Your Diagnostic Spot Globally
              </h2>
              <p className={`text-xs sm:text-sm leading-relaxed ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                Complete our clinical triage form to request a priority same-day consultation, global encrypted telemedicine slot, or custom preventative lifespan panel. Our concierge liaison will trigger callbacks in less than 2 hours.
              </p>

              <div className="p-5 rounded-2xl bg-indigo-950/20 border border-indigo-500/10 space-y-4">
                <p className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 font-mono select-none">Clinic Entry Protocols:</p>
                
                <div className="space-y-3 text-xs font-semibold">
                  <div className="flex items-center gap-3">
                    <CheckCircle size={14} className="text-teal-400 shrink-0" />
                    <span>Bring all current genomic assays & prescriptions.</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle size={14} className="text-teal-400 shrink-0" />
                    <span>In-Clinic consultation includes physical vitals scan.</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle size={14} className="text-teal-400 shrink-0" />
                    <span>Telemedicine conducted via secure encrypted high-definition WebRTC video.</span>
                  </div>
                </div>
              </div>

              {/* Direct clinic phone details help */}
              <div className="border-t border-slate-800 pt-6 space-y-2 select-text">
                <p className="text-[10px] uppercase font-bold tracking-widest text-slate-500">Concierge Desk Direct Lines</p>
                <p className="text-sm font-mono font-bold">Reception Hotline: +91 11 4455 6677</p>
                <p className="text-sm font-mono font-bold text-red-400">Emergency Red-Triage Line: +91 98765 43210</p>
              </div>

            </div>

            {/* Booking Form Card right column */}
            <div className="lg:col-span-7 select-text">
              <BookingForm darkTheme={darkTheme} />
            </div>

          </div>
        </div>
      </section>

      {/* SECTION: HEALTH BLOG (RESEARCH & ESSAYS) */}
      <section id="blogs" className={`py-20 lg:py-28 border-y select-text ${darkTheme ? 'bg-slate-900/10 border-slate-900' : 'bg-slate-50 border-slate-200/50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <span className="text-xs font-bold uppercase tracking-widest text-teal-400 font-mono">Academic Insights & Clinical Guides</span>
            <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
              The Lifespan Intelligence Journal
            </h2>
            <p className={`text-xs sm:text-sm ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>
              Dr. S.K. Jain regularly synthesizes breakthrough medical science into clear clinical essays on cardiovascular prevention, metabolic management, intestinal microbiology, and proactive aging.
            </p>
          </div>

          {/* Mount the comprehensive HealthBlog component with state parameters */}
          <HealthBlog darkTheme={darkTheme} />

        </div>
      </section>

      {/* SECTION: CLINIC INFORMATION & REAL DIAGNOSTIC COORDINATES */}
      <section id="info" className="py-20 lg:py-28 select-text">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            
            {/* Address Details Left Column */}
            <div className="lg:col-span-5 space-y-8">
              
              <div className="space-y-4">
                <span className="text-xs font-bold uppercase tracking-widest text-teal-400 font-mono">Coordinates & Hours</span>
                <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                  Visit Our Premium Healthcare Center
                </h2>
                <p className={`text-xs sm:text-sm leading-relaxed ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>
                  Our enclave is located in Platinum Medical Heights, a state-of-the-art corporate diagnostics park fitted with private lounges, ICU ambulances, and diagnostic laboratories.
                </p>
              </div>

              {/* Exact Location Cards */}
              <div className="space-y-4 font-sans text-xs">
                
                <div className={`p-5 rounded-2xl border flex gap-3.5 items-start ${darkTheme ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-100 shadow-sm'}`}>
                  <MapPin size={22} className="text-teal-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className={`font-bold text-sm ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Clinic Address Coordinates</h4>
                    <p className={`mt-1.5 leading-relaxed leading-6 ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                      {CLINIC_INFO.address}
                    </p>
                    <a 
                      href={CLINIC_INFO.directionUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs text-teal-400 font-bold mt-4 hover:underline"
                    >
                      Fetch Directions on Maps <ArrowUpRight size={14} />
                    </a>
                  </div>
                </div>

                {/* Consultation Hours */}
                <div className={`p-5 rounded-2xl border ${darkTheme ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-100 shadow-sm'}`}>
                  <h4 className={`font-bold text-sm mb-3.5 ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Consultation Hours Schedule</h4>
                  <div className="space-y-3">
                    {CLINIC_INFO.hours.map((hour, hidx) => (
                      <div key={hidx} className="flex justify-between items-center text-xs py-1 border-b border-slate-700/10">
                        <span className={`font-bold ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>{hour.days}</span>
                        <div className="text-right select-all">
                          <p className={`font-mono font-semibold ${darkTheme ? 'text-slate-200' : 'text-slate-800'}`}>{hour.morning}</p>
                          <p className={`font-mono text-[10px] ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>{hour.evening}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>

            {/* Google map iframe Right Column */}
            <div className="lg:col-span-7 relative select-none">
              <div className="absolute inset-0 bg-gradient-to-tr from-teal-500/10 to-indigo-600/10 blur-[80px]" />
              
              <div className="relative p-2.5 rounded-[36px] bg-gradient-to-tr from-slate-700/20 to-slate-800/10 overflow-hidden shadow-2xl border border-slate-700/20">
                <div className="rounded-[26px] overflow-hidden">
                  <iframe 
                    src={CLINIC_INFO.mapUrl} 
                    width="100%" 
                    height="400" 
                    style={{ border: 0 }} 
                    allowFullScreen 
                    loading="lazy" 
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Dr. S.K. Jain AIIMS New Delhi Coordinates Map"
                    className="grayscale-[30%] contrast-[110%] opacity-90 hover:opacity-100 transition-opacity"
                  />
                </div>

                {/* Overlaid address navigation button card */}
                <div className={`absolute bottom-6 left-6 p-4 rounded-xl shadow-2xl flex items-center gap-3 border mr-6 ${
                  darkTheme ? 'bg-slate-950/90 border-slate-800 text-white' : 'bg-white/95 border-slate-100 text-slate-800'
                }`}>
                  <div className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-[11px] font-bold">AIIMS Enclave District • Priority Clearance Zone</span>
                </div>

              </div>

            </div>

          </div>
        </div>
      </section>

      {/* SECTION: ACCORDION FAQs */}
      <section id="faqs" className={`py-20 lg:py-28 border-y select-text ${darkTheme ? 'bg-slate-900/10 border-slate-900' : 'bg-slate-50 border-slate-200/50'}`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <span className="text-xs font-bold uppercase tracking-widest text-indigo-400 font-mono">Expert Answers</span>
            <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
              Clinical Processes & General Questions
            </h2>
            <p className={`text-xs sm:text-sm ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>
              Review direct transparency information about appointments scheduling, billing frameworks, telemedicine setups, and medication tracking.
            </p>
          </div>

          {/* Accordion Blocks */}
          <div className="space-y-4">
            {FAQ_ITEMS.map((faq) => (
              <div 
                key={faq.id} 
                className={`rounded-2xl border transition-all duration-300 ${
                  activeFaq === faq.id 
                    ? darkTheme 
                      ? 'bg-slate-900/60 border-teal-500/40' 
                      : 'bg-white border-teal-600 shadow-sm'
                    : darkTheme 
                      ? 'bg-slate-900/10 border-slate-800 hover:border-slate-700/80' 
                      : 'bg-white border-slate-150 hover:border-slate-200'
                }`}
              >
                
                {/* Header question toggle click */}
                <button
                  onClick={() => setActiveFaq(activeFaq === faq.id ? null : faq.id)}
                  className="w-full p-5 flex justify-between items-center text-left cursor-pointer transition-colors"
                >
                  <span className={`text-xs sm:text-sm font-bold tracking-tight pr-4 ${darkTheme ? 'text-slate-100 hover:text-white' : 'text-slate-800'}`}>
                    {faq.question}
                  </span>
                  <span className={`p-1 rounded-lg shrink-0 transition-transform ${
                    activeFaq === faq.id ? 'rotate-180 bg-teal-500/10 text-teal-400' : 'text-slate-400'
                  }`}>
                    <ChevronDown size={16} />
                  </span>
                </button>

                {/* Accordion body answers */}
                <AnimatePresence>
                  {activeFaq === faq.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border-t border-slate-700/10"
                    >
                      <div className={`p-5 text-xs leading-relaxed space-y-3 ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
                        <p>{faq.answer}</p>
                        <p className="text-[10px] text-teal-400 font-mono uppercase tracking-wider font-extrabold select-none">
                          Category: {faq.category}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>
            ))}
          </div>

        </div>
      </section>

      {/* SECTION: GENERAL CONTACT DETAIL */}
      <section className="py-20 lg:py-28 relative select-text">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            
            {/* Left direct channel contact options */}
            <div className="lg:col-span-5 space-y-8">
              <span className="text-xs font-bold uppercase tracking-widest text-teal-400 font-mono">Immediate Liaison Channels</span>
              <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                Have Specific Diagnostics Inquiries?
              </h2>
              <p className={`text-xs sm:text-sm leading-relaxed ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>
                Our medical concierge board handles all administrative files, surgical schedule koordinations, international visa clearances, insurance cash-free submissions, and medical audits seamlessly.
              </p>

              {/* Direct clickable item options */}
              <div className="space-y-4 font-sans text-xs">
                
                {/* Reception Call */}
                <a 
                  href={`tel:${CLINIC_INFO.receptionPhone}`}
                  className={`p-4 rounded-2xl border flex items-center gap-4 transition-all duration-300 hover:translate-x-1 outline-hidden ${
                    darkTheme ? 'bg-slate-900/30 border-slate-800 hover:border-slate-700' : 'bg-white border-slate-100 hover:border-slate-200 shadow-xs'
                  }`}
                >
                  <div className="p-2.5 bg-teal-500/10 text-teal-400 rounded-xl">
                    <Phone size={18} />
                  </div>
                  <div>
                    <h4 className={`font-bold text-sm ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Reception Concierge</h4>
                    <p className="text-[10px] text-slate-400 mt-1">Operational during catalog timings: {CLINIC_INFO.receptionPhone}</p>
                  </div>
                </a>

                {/* Support Email */}
                <a 
                  href={`mailto:${CLINIC_INFO.email}`}
                  className={`p-4 rounded-2xl border flex items-center gap-4 transition-all duration-300 hover:translate-x-1 outline-hidden ${
                    darkTheme ? 'bg-slate-900/30 border-slate-800 hover:border-slate-700' : 'bg-white border-slate-100 hover:border-slate-200 shadow-xs'
                  }`}
                >
                  <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl">
                    <Mail size={18} />
                  </div>
                  <div>
                    <h4 className={`font-bold text-sm ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Clinical Communications</h4>
                    <p className="text-[10px] text-slate-400 mt-1">Submit reports copy, genomic audits: {CLINIC_INFO.email}</p>
                  </div>
                </a>

                {/* Emergency direct phone Alert */}
                <div className="p-4 rounded-2xl bg-red-500/5 border border-red-500/10 flex items-center gap-4">
                  <div className="p-2.5 bg-red-500/15 text-red-500 rounded-xl shrink-0 animate-pulse">
                    <PhoneCall size={18} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-red-400">Emergency Red-Triage Hotline</h4>
                    <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-wider font-semibold">Priority ICU Ambulances: +91 98765 43210</p>
                  </div>
                </div>

              </div>
            </div>

            {/* Quick Contact Form Right column */}
            <div className={`lg:col-span-7 p-6 sm:p-8 rounded-3xl border ${
              darkTheme ? 'bg-slate-900/40 border-slate-800 shadow-2xl' : 'bg-white border-slate-100 shadow-lg'
            }`}>
              <h3 className={`text-xl font-bold tracking-tight mb-2 ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                Concierge Callback Request
              </h3>
              <p className={`text-xs mb-6 ${darkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                Leave continuous feedback or questions, and our clinical liaison board will reach out to you within 2 business hours.
              </p>

              <form onSubmit={(e) => { e.preventDefault(); alert("Concierge Callback Slot Registered! Our Liaison board will phone you shortly."); }} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider mb-2">Patient Name</label>
                    <input 
                      type="text" 
                      required 
                      placeholder="e.g. Arvind" 
                      className={`block w-full px-4 py-2.5 text-xs rounded-xl border outline-hidden ${
                        darkTheme ? 'bg-slate-950 border-slate-800 text-white focus:border-teal-400' : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider mb-2">Active Mobile</label>
                    <input 
                      type="tel" 
                      required 
                      placeholder="+91 987..." 
                      className={`block w-full px-4 py-2.5 text-xs rounded-xl border outline-hidden ${
                        darkTheme ? 'bg-slate-950 border-slate-800 text-white focus:border-teal-400' : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider mb-2">Clinical Message Inquiry</label>
                  <textarea 
                    rows={3} 
                    required 
                    placeholder="Describe specific second-opinion inquiries, insurance requirements..." 
                    className={`block w-full px-4 py-2.5 text-xs rounded-xl border outline-hidden ${
                      darkTheme ? 'bg-slate-950 border-slate-800 text-white focus:border-teal-400' : 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-900'
                    }`}
                  />
                </div>

                <div className="flex justify-between items-center select-none pt-2">
                  <span className="text-[10px] text-slate-500 inline-flex items-center gap-1">
                    <Lock size={12} /> SSL Secured Data Encrypted
                  </span>
                  <button 
                    type="submit" 
                    className="px-6 py-3 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold tracking-wider uppercase rounded-xl cursor-pointer shadow-md transition-colors"
                  >
                    Submit Request
                  </button>
                </div>
              </form>

            </div>

          </div>
        </div>
      </section>

      {/* FOOTER AREA */}
      <footer className={`py-16 border-t font-sans text-xs select-text ${
        darkTheme ? 'bg-slate-950 border-slate-900 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-600'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Logo & Info column */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 bg-teal-500 text-white font-extrabold flex items-center justify-center rounded-lg">SJ</div>
              <span className={`text-base font-extrabold tracking-tight ${darkTheme ? 'text-white' : 'text-slate-950'}`}>DR. S.K. JAIN</span>
            </div>
            <p className="leading-relaxed leading-6">
              Meticulous Clinical Diagnosis, Longevity Therapeutics, and Chronic Care Management programs based in New Delhi, India. Operating under strict Delhi Medical Board accredetations.
            </p>
            <p className="text-[10px] text-slate-500">
              Copyright © 2026 Dr. S.K. Jain Preventative Diagnostics. All medical rights reserved.
            </p>
          </div>

          {/* Specialty links Column */}
          <div className="md:col-span-3 space-y-4 select-none">
            <h4 className={`font-bold tracking-wider uppercase text-[10px] ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Clinical Specialties</h4>
            <div className="flex flex-col gap-2.5">
              <button onClick={() => { scrollToSection('services'); setSelectedService('general-consultation'); }} className="text-left hover:text-teal-400 transition-colors cursor-pointer">General Consultation</button>
              <button onClick={() => { scrollToSection('services'); setSelectedService('preventive-healthcare'); }} className="text-left hover:text-teal-400 transition-colors cursor-pointer">Preventive & Lifespan Therapeutics</button>
              <button onClick={() => { scrollToSection('services'); setSelectedService('comprehensive-checkups'); }} className="text-left hover:text-teal-400 transition-colors cursor-pointer">Executive Health Screenings</button>
              <button onClick={() => { scrollToSection('services'); setSelectedService('chronic-disease-management'); }} className="text-left hover:text-teal-400 transition-colors cursor-pointer">Chronic Disease Management</button>
            </div>
          </div>

          {/* Quick links Column */}
          <div className="md:col-span-2 space-y-4 select-none">
            <h4 className={`font-bold tracking-wider uppercase text-[10px] ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Quick Portal Links</h4>
            <div className="flex flex-col gap-2.5">
              <button onClick={() => scrollToSection('about')} className="text-left hover:text-teal-400 transition-colors cursor-pointer">Biography Profile</button>
              <button onClick={() => scrollToSection('blogs')} className="text-left hover:text-teal-400 transition-colors cursor-pointer">Lifespan Journal</button>
              <button onClick={() => scrollToSection('faqs')} className="text-left hover:text-teal-400 transition-colors cursor-pointer">Process FAQs</button>
              <button onClick={() => scrollToSection('booking')} className="text-left hover:text-teal-400 transition-colors cursor-pointer">Secure Booking Slip</button>
            </div>
          </div>

          {/* Location details */}
          <div className="md:col-span-3 space-y-4 select-text">
            <h4 className={`font-bold tracking-wider uppercase text-[10px] ${darkTheme ? 'text-white' : 'text-slate-950'}`}>Consulting Hours office</h4>
            <p className="leading-relaxed">
              Platinum Medical Heights, 4th Floor, New Delhi, India 110025. Contact desk opens Mon-Sat 9:00 AM to 8:30 PM.
            </p>
            <div className="flex items-center gap-4 pt-1 flex-wrap select-none">
              <a href={CLINIC_INFO.socials.linkedin} target="_blank" rel="noopener noreferrer" className="hover:text-teal-400">LinkedIn</a>
              <a href={CLINIC_INFO.socials.twitter} target="_blank" rel="noopener noreferrer" className="hover:text-teal-400">Twitter</a>
              <a href={CLINIC_INFO.socials.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-teal-400">Instagram</a>
              <a href={CLINIC_INFO.socials.youtube} target="_blank" rel="noopener noreferrer" className="hover:text-teal-400">YouTube</a>
            </div>
          </div>

        </div>

        {/* SECURE SUB-FOOTER */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-slate-700/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] select-none text-slate-500">
          <div className="flex items-center gap-6">
            <a href="#about" className="hover:underline">Privacy Policy Statement</a>
            <a href="#about" className="hover:underline">Clinical Terms & Coordinates</a>
            <a href="#about" className="hover:underline">DMC Disclosures</a>
          </div>
          <p className="text-right">
            Clinical Platform verified under Apollo strategic care boards list. Built statically for lightning-fast speeds.
          </p>
        </div>
      </footer>

      {/* NETLIFY DEPLOYMENT ENHANCEMENT NOTICE FOR ZIP USER */}
      <div className="hidden">
        {/* Under the hood deployment indicators to streamline drag-and-drop on netlify dashboards */}
        <p>Target Framework: Statically compiled Vite client React component system</p>
        <p>Direct live link index folder: dist/ directory contains all assets, html, js and stylesheet index</p>
      </div>

    </div>
  );
}
