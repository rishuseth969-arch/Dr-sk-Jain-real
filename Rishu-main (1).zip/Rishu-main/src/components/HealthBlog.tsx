import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Calendar, User, Clock, ChevronRight, X, ArrowLeft, BookOpen, Quote, Share2, AlertTriangle } from 'lucide-react';
import { BlogPost } from '../types';
import { BLOG_POSTS } from '../data';

interface HealthBlogProps {
  darkTheme: boolean;
}

const CATEGORIES = ["All", "Wellness", "Heart Health", "Diabetes", "Preventive"];

export default function HealthBlog({ darkTheme }: HealthBlogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [activePost, setActivePost] = useState<BlogPost | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Search and filter logic
  const filteredPosts = BLOG_POSTS.filter(post => {
    const matchesSearch = 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = 
      selectedCategory === 'All' || 
      post.category === selectedCategory || 
      (selectedCategory === 'Heart Health' && post.category === 'Heart Health');

    return matchesSearch && matchesCategory;
  });

  const handleShare = (title: string) => {
    setCopiedLink(true);
    navigator.clipboard.writeText(window.location.href + '?' + encodeURIComponent(title));
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Search and Filters Strip */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-slate-50/10 p-4 rounded-2xl border border-slate-700/5 backdrop-blur-xs">
        {/* Search */}
        <div className="relative w-full md:w-96 select-text">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search size={16} />
          </div>
          <input
            type="text"
            placeholder="Search symptoms, dynamic biomarkers, protocols..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-10 pr-4 py-2.5 text-xs rounded-xl border outline-hidden transition-all duration-300 ${
              darkTheme
                ? 'bg-slate-900 border-slate-800 text-white focus:border-teal-400'
                : 'bg-white border-slate-200 text-slate-900 focus:border-teal-600'
            }`}
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-100 text-xs cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>

        {/* Categories Chips */}
        <div className="flex flex-wrap gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 scrollbar-none select-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all duration-300 transform active:scale-95 ${
                selectedCategory === cat
                  ? 'bg-teal-600 text-white shadow-md shadow-teal-900/10'
                  : darkTheme
                    ? 'bg-slate-900/40 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800'
                    : 'bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-900 border border-slate-200/60'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Blogs Mapping */}
      {filteredPosts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 lg:gap-8">
          {filteredPosts.map((post, idx) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
              className={`group flex flex-col rounded-3xl overflow-hidden border transition-all duration-300 hover:shadow-2xl hover:translate-y-[-4px] cursor-pointer ${
                darkTheme
                  ? 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700'
                  : 'bg-white border-slate-100 hover:border-slate-200'
              }`}
              onClick={() => setActivePost(post)}
            >
              {/* Image banner */}
              <div className="relative h-56 w-full overflow-hidden shrink-0 select-none">
                <img
                  src={post.image}
                  alt={post.title}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3.5 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest bg-dark/80 backdrop-blur-md text-teal-400 border border-teal-500/20 shadow-lg">
                    {post.category}
                  </span>
                </div>
              </div>

              {/* Content box */}
              <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center gap-4 text-[11px] font-semibold text-teal-500 font-mono">
                    <span className="flex items-center gap-1.5">
                      <Calendar size={13} />
                      {post.date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock size={13} />
                      {post.readTime}
                    </span>
                  </div>

                  <h3 className={`text-lg font-bold leading-snug group-hover:text-teal-400 transition-colors ${
                    darkTheme ? 'text-white' : 'text-slate-900'
                  }`}>
                    {post.title}
                  </h3>

                  <p className={`text-xs line-clamp-2 leading-relaxed ${
                    darkTheme ? 'text-slate-300' : 'text-slate-500'
                  }`}>
                    {post.excerpt}
                  </p>
                </div>

                <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-700/10">
                  <span className={`text-[11px] font-bold flex items-center gap-2 ${
                    darkTheme ? 'text-slate-400' : 'text-slate-600'
                  }`}>
                    <span className="h-6 w-6 rounded-full bg-teal-500/10 text-teal-400 font-semibold text-xs flex items-center justify-center border border-teal-500/25">
                      SJ
                    </span>
                    {post.author}
                  </span>
                  <span className="text-xs font-bold text-teal-500 flex items-center gap-1.5 group-hover:gap-2.5 transition-all">
                    Read Medical Article
                    <ChevronRight size={14} />
                  </span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-slate-500/5 rounded-3xl border border-dashed border-slate-700/20">
          <BookOpen className="mx-auto text-slate-500 mb-4 h-12 w-12 stroke-1" />
          <p className={`text-sm font-semibold ${darkTheme ? 'text-slate-300' : 'text-slate-600'}`}>
            No diagnostic essays matched your biometric filter.
          </p>
          <p className="text-xs text-slate-500 mt-1">Try clarifying keywords or check other schedules.</p>
        </div>
      )}

      {/* Reading Article Modal */}
      <AnimatePresence>
        {activePost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex justify-center items-center p-4 md:p-6 overflow-y-auto cursor-auto"
            onClick={() => setActivePost(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 30 }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className={`w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl border flex flex-col my-8 select-text ${
                darkTheme ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-100 text-slate-800'
              }`}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Banner */}
              <div className="relative h-64 md:h-80 w-full shrink-0 select-none">
                <img
                  src={activePost.image}
                  alt={activePost.title}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent flex items-end">
                  <div className="p-6 md:p-8 space-y-3">
                    <span className="px-3 py-1 bg-teal-600 text-white font-bold text-[10px] tracking-wider uppercase rounded-full">
                      {activePost.category}
                    </span>
                    <h2 className="text-xl md:text-3xl font-bold tracking-tight text-white font-sans max-w-2xl leading-tight">
                      {activePost.title}
                    </h2>
                  </div>
                </div>
                {/* Close Button */}
                <button
                  onClick={() => setActivePost(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-slate-950/70 hover:bg-slate-950 text-white transition-colors cursor-pointer"
                  title="Close Reader"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Specs bar */}
              <div className={`p-4 px-6 md:px-8 flex flex-wrap justify-between items-center gap-4 border-b text-xs font-semibold ${
                darkTheme ? 'bg-slate-950/60 border-slate-800/80 text-slate-400' : 'bg-slate-50 border-slate-100 text-slate-600'
              } select-none`}>
                <div className="flex items-center gap-5">
                  <span className="flex items-center gap-1.5">
                    <User size={14} className="text-teal-500" />
                    By {activePost.author}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Calendar size={14} className="text-teal-500" />
                    {activePost.date}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Clock size={14} className="text-teal-500" />
                    {activePost.readTime}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleShare(activePost.title)}
                    className="p-1.5 rounded-lg hover:bg-slate-500/10 hover:text-teal-400 transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider"
                  >
                    <Share2 size={13} />
                    {copiedLink ? 'Copied' : 'Share'}
                  </button>
                </div>
              </div>

              {/* Essay content */}
              <div className={`p-6 md:p-8 md:px-10 overflow-y-auto max-h-[50dvh] space-y-6 ${
                darkTheme ? 'bg-slate-950/10' : 'bg-white'
              }`}>
                {/* Visual quote indicator */}
                <div className="flex gap-3 text-teal-500/20 select-none">
                  <Quote size={32} className="shrink-0 text-teal-500" />
                  <p className={`text-sm italic font-medium leading-relaxed ${
                    darkTheme ? 'text-teal-300/90' : 'text-teal-900/80'
                  }`}>
                    {activePost.excerpt}
                  </p>
                </div>

                {/* Main Text Content */}
                <div className={`text-sm font-sans leading-relaxed whitespace-pre-wrap space-y-4 ${
                  darkTheme ? 'text-slate-200' : 'text-slate-700'
                }`}>
                  {activePost.content}
                </div>

                {/* Clinical note */}
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/15 text-xs text-amber-500 leading-relaxed font-sans space-y-2 select-none">
                  <div className="flex items-center gap-1.5 font-bold">
                    <AlertTriangle size={15} /> CLINICAL ADVICE INTERVENTION
                  </div>
                  <p>
                    This literature is published under the public disease awareness curriculum of Delhi Med-Board guidelines for educational use only. It cannot displace physical clinical diagnostician clearances. Schedule an appointment for personalized diagnostic validation.
                  </p>
                </div>
              </div>

              {/* Footer navigation */}
              <div className={`p-4 md:p-6 px-8 border-t flex justify-end gap-3 select-none ${
                darkTheme ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <button
                  onClick={() => setActivePost(null)}
                  className="px-6 py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-lg shadow-teal-950/30 font-sans"
                >
                  Finished Reading
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
