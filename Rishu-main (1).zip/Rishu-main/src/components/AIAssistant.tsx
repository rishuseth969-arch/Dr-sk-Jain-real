import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Bot, User, ShieldAlert, Sparkles, Key, Check, Info, AlertTriangle } from 'lucide-react';
import { Message } from '../types';
import { GoogleGenAI } from '@google/genai';

interface AIAssistantProps {
  darkTheme: boolean;
}

const PRESET_TOPICS = [
  { id: "heart", label: "💓 Cardiovascular Check" },
  { id: "diabetes", label: "🍬 Sugar/Diabetes Triage" },
  { id: "pricing", label: "💳 Booking & Consultation Fees" },
  { id: "general", label: "📈 General Wellness Advice" }
];

const PRESET_RESPONSES: Record<string, { text: string; options: string[] }> = {
  heart: {
    text: "💓 *CARDIOVASCULAR TRIAGE CHECK:* Dr. S.K. Jain specializes in modern plaque assessment and bio-nutrition protocols to optimize arterial flow.\n\n*General Advice:* If you are experiencing mild palpitations, elevated blood pressure spikes, or have a family history of CAD, we suggest scheduling an *Executive screening checkup*.\n\n**⚠️ RED FLAG WARNING:** If you are experiencing sudden radiating chest pressure, severe shortness of breath, or numbness in your left arm, call emergency dispatch immediately (*+91 98765 43210*) or head to the nearest cardiac ICU. Do not use AI diagnostic tools for active cardiac crises.",
    options: ["Book Cardiac Consultation", "Read Heart Blogs", "See Standard Charges"]
  },
  diabetes: {
    text: "🍬 *INSULIN RESISTANCE & GLYCEMIC TRIAGE:* We prioritize continuous glucose monitoring (CGM) protocols combined with vascular strength training over simple chemical management.\n\n*Recommendations:* If your A1C is persistently above 6.5%, Dr. Jain recommend custom metabolic tracking. For fasting readings above 140 mg/dL, schedule a *Chronic Care Management Consultation* immediately.\n\nWould you like to examine our diabetes reverse protocols?",
    options: ["Show Diabetes CCM Services", "Read Insulin Resistance Blogs", "Book Consultation Slot"]
  },
  pricing: {
    text: "💳 *CONSULTATION CHARGES & SCHEDULES:* Information on clinic parameters is fully transparent:\n\n- **In-Clinic consultation:** INR 1,500 includes comprehensive physical diagnostics and prescription planning (30 mins Slot).\n- **Encrypted video Telemedicine:** INR 1,200 allows global audio/video sessions on encrypted WebRTC paths.\n- **Priority follow-ups & Tele-audits:** Free for CCM-registered corporate patients.\n\nWould you like to reserve a consultation with Dr. S.K. Jain now?",
    options: ["Book Appointment Now", "View Other Clinic Services"]
  },
  general: {
    text: "📈 *METABOLIC WELLNESS & LIFESPAN INDEX:*\n\nDr. S.K. Jain advocates for proactive aging therapeutics. Key markers to track:\n- ApoB, hs-CRP, and insulin sensitivity profiles.\n- Daily fiber profiling (target 35g+).\n- Muscle maintenance via targeted resistance conditioning.\n\nLet me know if you would like parameters explained.",
    options: ["Explore Executive Health Packages", "Browse Wellness Blogs", "Consult Now"]
  }
};

export default function AIAssistant({ darkTheme }: AIAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'assistant',
      text: "👋 Welcome to Dr. S.K. Jain's Premium Clinical Concierge. I am S.K. Jain AI, trained in advanced pre-triage standards.\n\nHow can I support your clinical wellness path today? Select an assessment catalog below or type custom biometrics.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [showKeySetup, setShowKeySetup] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Load API Key from localStorage on mount
  useEffect(() => {
    const savedKey = localStorage.getItem('dr_sk_jain_gemini_key');
    if (savedKey) {
      setApiKey(savedKey);
    }
  }, []);

  // Auto-scroll on new message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleApiKeySave = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('dr_sk_jain_gemini_key', apiKey);
    setShowKeySetup(false);
    
    setMessages(prev => [
      ...prev,
      {
        sender: 'assistant',
        text: `🔓 **Gemini AI Core Unlocked.** I am now fueled by real-time neural models. Ask me anything about disease awareness, medical science, or Dr. Jain's clinic protocols!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  const handlePresetClick = (id: string) => {
    const preset = PRESET_RESPONSES[id];
    if (!preset) return;

    const userMsg: Message = {
      sender: 'user',
      text: PRESET_TOPICS.find(t => t.id === id)?.label || id,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [
        ...prev,
        {
          sender: 'assistant',
          text: preset.text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          triageChoice: preset.options
        }
      ]);
    }, 850);
  };

  const transmitCustomMsg = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    // Check if live Gemini API key is available
    const savedKey = localStorage.getItem('dr_sk_jain_gemini_key');
    if (savedKey && savedKey.startsWith('AIzaSy')) {
      try {
        const ai = new GoogleGenAI({ 
          apiKey: savedKey,
          httpOptions: {
            headers: { 'User-Agent': 'aistudio-build' }
          }
        });

        // Setup healthcare context instruction
        const contextInstruction = `You are "Acuity AI Triage Bot", the exclusive virtual clinical concierge for Dr. S.K. Jain, an elite senior consultant physician based in New Delhi, India. 
Dr. S.K. Jain's details: MBBS, MD (Medicine), 24+ years of experience, former chief diagnostic fellow, consulting at Platinum Medical Enclave. Consultation fees: INR 1500 (in-clinic), INR 1200 (encrypted telemedicine). Clinic emergency: +91 98765 43210.
RULES:
1. Provide highly academic, accurate, empathetic clinical intelligence about common diagnoses, chronic diseases (diabetes, heart disease, thyroid), longevity protocols, and microbiome wellness.
2. ALWAYS provide a clinical red flag disclaimer if symptoms sound dangerous (chest paint, sudden slurring, breathlessness, etc.) advising them to call the emergency hotline.
3. Keep answers compact, professional, formatted nicely with bullet points and bolding.
4. Encourage the user to fill out the consultation booking form on the webpage to obtain a certified physical checkup.
5. Remind that AI is for informational pre-triage only, not a diagnostic replacement.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: textToSend,
          config: {
            systemInstruction: contextInstruction,
            temperature: 0.7
          }
        });

        const reply = response.text || "Apologies, I encountered an empty cerebral synapse. Let me retry.";
        
        setIsTyping(false);
        setMessages(prev => [
          ...prev,
          {
            sender: 'assistant',
            text: reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        return;
      } catch (err: any) {
        console.error("Gemini API direct query error:", err);
        // Fallback with disclaimer
      }
    }

    // Default Smart Pre-programmed Response System
    setTimeout(() => {
      setIsTyping(false);
      
      let systemReply = "";
      const lowerText = textToSend.toLowerCase();

      if (lowerText.includes("heart") || lowerText.includes("cardio") || lowerText.includes("chest") || lowerText.includes("bp") || lowerText.includes("blood pressure")) {
        systemReply = "💓 **Cardiac Triage Notice:** Dr. S.K. Jain specializes in advanced preventative cardiology, identifying early vascular plaque accumulation before crisis levels. \n\nIf you are experiencing chest pressure, radiation into the jaw, or severe dyspnea, call **+91 98765 43210** immediately! For routine blood pressure management, we suggest scheduling an *Executive diagnostic session* via our booking module.";
      } else if (lowerText.includes("sugar") || lowerText.includes("diabet") || lowerText.includes("insulin") || lowerText.includes("glucose")) {
        systemReply = "🍬 **Glycemic Auditing:** Dr. Jain administers Continuous Glucose Monitor (CGM) integrated pathways. By mapping exact daily glucose curves, patients can systematically reverse insulin resistance through bio-nutrition and strength habits.\n\nWould you like to examine our Chronic Disease Care Management services?";
      } else if (lowerText.includes("fee") || lowerText.includes("charge") || lowerText.includes("price") || lowerText.includes("cost") || lowerText.includes("money")) {
        systemReply = "💳 **Clinical Fees Parameters:**\n\n- **In-Clinic General Diagnostic Panel:** INR 1,500\n- **Encrypted Global Telemedicine video slot:** INR 1,200\n- **Chronic Care Tracking (Monthly subscription):** Fully customizable. \n\nWe coordinate flawless cashless claims with major insurances such as Star Health, Apollo Munich, ICICI, and Cigna.";
      } else if (lowerText.includes("hello") || lowerText.includes("hi") || lowerText.includes("hey") || lowerText.includes("who are you")) {
        systemReply = "👋 Hello! I am the Dr. S.K. Jain AI Clinical Assistant. I can pre-screen health issues, explain lifespan longevity tests, and clarify booking fees. Feel free to ask about cardiac risk markers, diabetes reversal plans, or clinic location details.";
      } else if (lowerText.includes("book") || lowerText.includes("appointment") || lowerText.includes("schedule") || lowerText.includes("timing")) {
        systemReply = "📅 **Schedule Management:** To book high-priority diagnostic clearances with Dr. S.K. Jain directly, simply scroll to our **Premium Appointment Section** on this page, fill in your details, and select your preferred slot. Alternatively, contact our concierge Desk at **+91 11 4455 6677**.";
      } else if (lowerText.includes("where") || lowerText.includes("location") || lowerText.includes("address") || lowerText.includes("map")) {
        systemReply = "📍 **Clinic Coordinates:** We are located at S.K. Jain Healthcare Center, 4th Floor, Platinum Medical Enclave, Apollo Road, New Delhi, India. Operating hours are Monday-Friday (9 AM to 1 PM, 4:30 PM to 8:30 PM). Scroll down to our Interactive Map to fetch custom directions!";
      } else {
        systemReply = `🧑‍⚕️ **Health Concierge Note:** Thank you for sharing. Dr. S.K. Jain's protocols emphasize evaluating molecular metrics (like hs-CRP, ApoB, gut-microbiome status, thyroid fractions) rather than superficial symptom blocking.\n\n*Informational Disclaimer:* I am an AI assistant. To analyze this specific situation, Dr. Jain recommends reserving an official **Video Telemedicine** or **In-Clinic Consultation** slot. Use the Booking System above.`;
      }

      setMessages(prev => [
        ...prev,
        {
          sender: 'assistant',
          text: systemReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 1000);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    transmitCustomMsg(inputValue);
  };

  return (
    <>
      {/* Floating Chat Trigger Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        id="ai-concierge-trigger"
        className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-4 bg-gradient-to-r from-teal-600 to-indigo-700 hover:from-teal-500 hover:to-indigo-600 text-white font-semibold rounded-full shadow-2xl cursor-pointer hover:shadow-teal-500/20 hover:scale-105 active:scale-95 transition-all duration-300 border border-white/10"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Bot size={24} className="animate-pulse" />
        <span className="text-sm tracking-wide hidden sm:inline select-none">AI Clinical Assistant</span>
        <span className="flex h-2.5 w-2.5 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-teal-500"></span>
        </span>
      </motion.button>

      {/* Slide-out/Fade chat panel */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 sm:inset-auto sm:bottom-24 sm:right-6 z-50 flex items-end justify-center sm:justify-end p-0 sm:p-4">
            
            {/* Background screen overlay for tiny devices */}
            <div 
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs sm:hidden"
              onClick={() => setIsOpen(false)}
            />

            <motion.div
              layoutId="ai-chat-box"
              initial={{ opacity: 0, y: 50, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.95 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className={`relative w-full h-[100dvh] sm:h-[600px] sm:w-[420px] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden border flex flex-col ${
                darkTheme 
                  ? 'bg-slate-900 border-slate-800 text-white' 
                  : 'bg-white border-slate-100 text-slate-800'
              }`}
            >
              {/* Header */}
              <div className="p-4 bg-gradient-to-r from-slate-950 via-slate-900 to-teal-950 text-white flex items-center justify-between border-b border-teal-500/20">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-teal-500/10 rounded-xl border border-teal-500/20 text-teal-400">
                    <Bot size={22} />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold tracking-tight flex items-center gap-1.5 leading-none">
                      Dr. Jain AI Concierge
                      <Sparkles size={12} className="text-teal-400 animate-pulse" />
                    </h4>
                    <p className="text-[10px] text-teal-300 mt-1 font-medium font-mono uppercase tracking-widest leading-none">
                      Clinical Pre-Triage Bot
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowKeySetup(!showKeySetup)}
                    className={`p-2 rounded-xl text-xs hover:bg-white/10 transition-colors cursor-pointer flex items-center gap-1.5 ${
                      apiKey ? 'text-teal-400' : 'text-slate-400'
                    }`}
                    title="Unlock live Gemini core with your API key"
                  >
                    <Key size={15} />
                    {apiKey && <Check size={12} />}
                  </button>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-2 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>

              {/* Secure API Key Configuration Overlay */}
              <AnimatePresence>
                {showKeySetup && (
                  <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="p-4 bg-slate-950 text-white border-b border-teal-500/20 space-y-3 z-10"
                  >
                    <div className="flex items-start gap-2.5">
                      <Info size={16} className="text-teal-400 mt-0.5 shrink-0" />
                      <p className="text-[11px] leading-relaxed text-slate-300">
                        Maximize this assistant's clinical brainpower! Paste your client-side **Gemini API Key** below to ask deep medical advice. Your key is stored securely in your browser's private `localStorage` only.
                      </p>
                    </div>
                    <form onSubmit={handleApiKeySave} className="flex gap-2">
                      <input
                        type="password"
                        placeholder="AIzaSy..."
                        value={apiKey}
                        onChange={(e) => setApiKey(e.target.value)}
                        className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-white placeholder-slate-500 focus:outline-hidden focus:border-teal-500"
                      />
                      <button
                        type="submit"
                        className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-xs font-semibold cursor-pointer shrink-0"
                      >
                        Unlock
                      </button>
                    </form>
                    {apiKey && (
                      <button
                        onClick={() => {
                          localStorage.removeItem('dr_sk_jain_gemini_key');
                          setApiKey('');
                          setShowKeySetup(false);
                        }}
                        className="text-[10px] text-red-400 underline hover:text-red-300 block pointer-events-auto"
                      >
                        Reset / Delete Key
                      </button>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Disclaimer Bar */}
              <div className="px-4 py-2 bg-amber-500/10 border-b border-amber-500/10 flex items-center gap-2 select-none">
                <ShieldAlert size={14} className="text-amber-500 shrink-0 animate-bounce" />
                <p className="text-[10px] text-amber-500 leading-none truncate font-medium">
                  AI informational check. In emergency call Emergency Triage directly: +91 98765 43210
                </p>
              </div>

              {/* Messages Body */}
              <div className={`flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin ${
                darkTheme ? 'bg-slate-950/20' : 'bg-slate-50/40'
              }`}>
                {messages.map((m, idx) => (
                  <div
                    key={idx}
                    className={`flex items-start gap-2.5 max-w-[85%] ${
                      m.sender === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
                    }`}
                  >
                    {/* User-Assistant avatar badge */}
                    <div className={`p-1.5 rounded-lg shrink-0 ${
                      m.sender === 'user' 
                        ? 'bg-teal-600 text-white' 
                        : darkTheme 
                          ? 'bg-slate-800 border border-slate-700 text-teal-400' 
                          : 'bg-white border border-slate-200 text-slate-700'
                    }`}>
                      {m.sender === 'user' ? <User size={14} /> : <Bot size={14} />}
                    </div>

                    <div className="space-y-2">
                      <div className={`p-3.5 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap ${
                        m.sender === 'user'
                          ? 'bg-teal-600 text-white rounded-tr-none'
                          : darkTheme
                            ? 'bg-slate-900 border border-slate-800 text-slate-100 rounded-tl-none'
                            : 'bg-white border border-slate-100 text-slate-800 shadow-sm rounded-tl-none'
                      }`}>
                        {m.text}
                      </div>

                      {/* Display suggestions chips below assistant responses */}
                      {m.triageChoice && m.triageChoice.length > 0 && (
                        <div className="flex flex-wrap gap-2 pt-1">
                          {m.triageChoice.map((opt, oIdx) => (
                            <button
                              key={oIdx}
                              onClick={() => transmitCustomMsg(opt)}
                              className={`px-2.5 py-1.5 rounded-lg text-[10px] border font-medium cursor-pointer transition-all duration-200 hover:scale-102 ${
                                darkTheme
                                  ? 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-teal-400 hover:text-teal-300'
                                  : 'bg-white hover:bg-slate-50 border-slate-200 text-teal-600 hover:text-teal-500 shadow-xs'
                              }`}
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      )}
                      
                      <span className={`block text-[9px] ${
                        m.sender === 'user' ? 'text-right' : 'text-left'
                      } ${darkTheme ? 'text-slate-500' : 'text-slate-400'}`}>
                        {m.timestamp}
                      </span>
                    </div>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex items-start gap-2.5 max-w-[80%] mr-auto">
                    <div className={`p-1.5 rounded-lg shrink-0 ${
                      darkTheme ? 'bg-slate-800 border border-slate-700 text-teal-400' : 'bg-white border border-slate-200 text-slate-700'
                    }`}>
                      <Bot size={14} />
                    </div>
                    <div className={`p-3 bg-opacity-40 rounded-2xl rounded-tl-none flex items-center gap-1 ${
                      darkTheme ? 'bg-slate-950 border border-slate-800' : 'bg-white border border-slate-100'
                    }`}>
                      <span className="dot animate-bounce h-1.5 w-1.5 bg-teal-400 rounded-full" style={{ animationDelay: '0ms' }} />
                      <span className="dot animate-bounce h-1.5 w-1.5 bg-teal-400 rounded-full" style={{ animationDelay: '150ms' }} />
                      <span className="dot animate-bounce h-1.5 w-1.5 bg-teal-400 rounded-full" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Chat Presets Rail */}
              {messages.length === 1 && (
                <div className="p-3 border-t border-slate-700/10 space-y-1.5 select-none shrink-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-teal-500 flex items-center gap-1 select-none">
                    <Sparkles size={11} /> Smart Pre-screening Catalogues
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {PRESET_TOPICS.map((topic) => (
                      <button
                        key={topic.id}
                        onClick={() => handlePresetClick(topic.id)}
                        className={`text-[10px] px-2.5 py-1.5 rounded-lg border font-semibold cursor-pointer transition-all duration-200 hover:scale-103 ${
                          darkTheme
                            ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-900 shadow-xs'
                        }`}
                      >
                        {topic.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input Form Footer */}
              <form onSubmit={handleSend} className="p-3 border-t border-slate-700/10 flex gap-2 shrink-0">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Ask about symptoms, ApoB, diabetes protocols..."
                  className={`flex-1 px-4 py-2.5 text-xs rounded-xl border outline-hidden transition-all duration-200 ${
                    darkTheme
                      ? 'bg-slate-950 border-slate-800 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400'
                      : 'bg-slate-50 border-slate-200 text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                  }`}
                />
                <button
                  type="submit"
                  disabled={!inputValue.trim()}
                  className="p-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl transition-all shadow-md active:scale-95 disabled:opacity-40 disabled:scale-100 disabled:cursor-not-allowed cursor-pointer shrink-0"
                >
                  <Send size={15} />
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
