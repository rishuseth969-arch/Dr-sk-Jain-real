import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Clock, User, Phone, Mail, FileText, CheckCircle, ArrowRight, Clipboard, Trash2 } from 'lucide-react';
import { Appointment } from '../types';

interface BookingFormProps {
  onSuccess?: () => void;
  darkTheme: boolean;
}

const CONSULTATION_TYPES = [
  "General Consultation & Diagnostics (In-Clinic)",
  "Preventive Healthcare & Lifespan Audit",
  "Executive Health Screening Panel",
  "Chronic Disease Care Management (CCM)",
  "Encrypted Video Telemedicine Session",
  "Direct Specialist Medical Coordination"
];

const AVAILABLE_TIMES = [
  "09:30 AM - 10:00 AM",
  "10:15 AM - 10:45 AM",
  "11:00 AM - 11:30 AM",
  "11:45 AM - 12:15 PM",
  "12:30 PM - 01:00 PM",
  "04:45 PM - 05:15 PM",
  "05:30 PM - 06:00 PM",
  "06:15 PM - 06:45 PM",
  "07:00 PM - 07:30 PM",
  "07:45 PM - 08:15 PM"
];

export default function BookingForm({ onSuccess, darkTheme }: BookingFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: '',
    time: AVAILABLE_TIMES[0],
    type: CONSULTATION_TYPES[0],
    message: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [recentBookings, setRecentBookings] = useState<Appointment[]>([]);
  const [lastAppointment, setLastAppointment] = useState<Appointment | null>(null);

  // Load bookings on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('dr_sk_jain_appointments');
      if (saved) {
        setRecentBookings(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Failed to load appointments", e);
    }
  }, []);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = "Full clinical name of the patient is required.";
    
    const phoneRegex = /^[+]?[0-9\s-]{10,14}$/;
    if (!formData.phone.trim()) {
      newErrors.phone = "Active phone number is required.";
    } else if (!phoneRegex.test(formData.phone.trim())) {
      newErrors.phone = "Please enter a valid phone number (e.g., +91 98765 43210).";
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = "Patient email address is required for sending clinical updates.";
    } else if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!formData.date) {
      newErrors.date = "Please select a preferred consulting date.";
    } else {
      const selected = new Date(formData.date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (selected < today) {
        newErrors.date = "Consultation date cannot be in the past.";
      }
      if (selected.getDay() === 0) { // Sunday
        newErrors.date = "Sunday is reserved for clinical emergencies only. Please select Mon-Sat.";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    // Simulate luxury API response latencies
    setTimeout(() => {
      setIsSubmitting(false);
      const newAppointment: Appointment = {
        id: 'APP-' + Math.floor(100000 + Math.random() * 900000),
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        date: formData.date,
        time: formData.time,
        type: formData.type,
        message: formData.message,
        status: 'Confirmed', // Luxury auto-confirm inside mock/preview
        createdAt: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })
      };

      const updatedHistory = [newAppointment, ...recentBookings];
      setRecentBookings(updatedHistory);
      setLastAppointment(newAppointment);
      localStorage.setItem('dr_sk_jain_appointments', JSON.stringify(updatedHistory));
      
      setShowSuccess(true);
      setFormData({
        name: '',
        phone: '',
        email: '',
        date: '',
        time: AVAILABLE_TIMES[0],
        type: CONSULTATION_TYPES[0],
        message: ''
      });

      if (onSuccess) onSuccess();
    }, 1200);
  };

  const deleteBooking = (id: string) => {
    const filtered = recentBookings.filter(b => b.id !== id);
    setRecentBookings(filtered);
    localStorage.setItem('dr_sk_jain_appointments', JSON.stringify(filtered));
  };

  return (
    <div className={`p-1 rounded-3xl ${darkTheme ? 'bg-gradient-to-br from-slate-800/80 to-slate-900/90' : 'bg-gradient-to-br from-white to-slate-50'} border ${darkTheme ? 'border-slate-700/80' : 'border-slate-100'} shadow-2xl`}>
      <div className="p-6 md:p-8">
        
        <AnimatePresence mode="wait">
          {!showSuccess ? (
            <motion.div
              key="booking-form"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className={`text-2xl font-bold tracking-tight mb-2 ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                Schedule an Appointment
              </h3>
              <p className={`text-sm mb-6 ${darkTheme ? 'text-slate-300' : 'text-slate-500'}`}>
                Book a high-priority premium diagnostic consultation slot. You will receive immediate digital and SMS confirmations.
              </p>

              <form onSubmit={handleBookingSubmit} className="space-y-5">
                {/* Full Name */}
                <div>
                  <label className={`block text-xs font-semibold uppercase tracking-wider mb-2 ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>
                    Patient Full Name
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User size={16} className={darkTheme ? 'text-slate-400' : 'text-slate-400'} />
                    </div>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="e.g. Arvind Mehra"
                      className={`block w-full pl-10 pr-3 py-3 text-sm rounded-xl outline-hidden border ${
                        errors.name 
                          ? 'border-red-500 focus:ring-1 focus:ring-red-500' 
                          : darkTheme 
                            ? 'border-slate-700 bg-slate-900/60 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400' 
                            : 'border-slate-200 bg-slate-50/50 text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                      } transition-all duration-200`}
                    />
                  </div>
                  {errors.name && <p className="mt-1 text-xs text-red-500 font-medium">{errors.name}</p>}
                </div>

                {/* Grid for Contact */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Phone Num */}
                  <div>
                    <label className={`block text-xs font-semibold uppercase tracking-wider mb-2 ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>
                      Mobile Phone
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone size={16} className={darkTheme ? 'text-slate-400' : 'text-slate-400'} />
                      </div>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="+91 98765 43210"
                        className={`block w-full pl-10 pr-3 py-3 text-sm rounded-xl outline-hidden border ${
                          errors.phone 
                            ? 'border-red-500 focus:ring-1 focus:ring-red-500' 
                            : darkTheme 
                              ? 'border-slate-700 bg-slate-900/60 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400' 
                              : 'border-slate-200 bg-slate-50/50 text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                        } transition-all duration-200`}
                      />
                    </div>
                    {errors.phone && <p className="mt-1 text-xs text-red-500 font-medium">{errors.phone}</p>}
                  </div>

                  {/* Email */}
                  <div>
                    <label className={`block text-xs font-semibold uppercase tracking-wider mb-2 ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>
                      Email Address
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail size={16} className={darkTheme ? 'text-slate-400' : 'text-slate-400'} />
                      </div>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="patient@example.com"
                        className={`block w-full pl-10 pr-3 py-3 text-sm rounded-xl outline-hidden border ${
                          errors.email 
                            ? 'border-red-500 focus:ring-1 focus:ring-red-500' 
                            : darkTheme 
                              ? 'border-slate-700 bg-slate-900/60 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400' 
                              : 'border-slate-200 bg-slate-50/50 text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                        } transition-all duration-200`}
                      />
                    </div>
                    {errors.email && <p className="mt-1 text-xs text-red-500 font-medium">{errors.email}</p>}
                  </div>
                </div>

                {/* Consultation Type */}
                <div>
                  <label className={`block text-xs font-semibold uppercase tracking-wider mb-2 ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>
                    Consultation Type
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Clipboard size={16} className={darkTheme ? 'text-slate-400' : 'text-slate-400'} />
                    </div>
                    <select
                      name="type"
                      value={formData.type}
                      onChange={handleChange}
                      className={`block w-full pl-10 pr-3 py-3 text-sm rounded-xl outline-hidden border ${
                        darkTheme 
                          ? 'border-slate-700 bg-slate-900 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400' 
                          : 'border-slate-200 bg-white text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                      } transition-all duration-200`}
                    >
                      {CONSULTATION_TYPES.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Date & Time */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Consulting Date */}
                  <div>
                    <label className={`block text-xs font-semibold uppercase tracking-wider mb-2 ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>
                      Select Date
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar size={16} className={darkTheme ? 'text-slate-400' : 'text-slate-400'} />
                      </div>
                      <input
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        className={`block w-full pl-10 pr-3 py-3 text-sm rounded-xl outline-hidden border ${
                          errors.date 
                            ? 'border-red-500 focus:ring-1 focus:ring-red-500' 
                            : darkTheme 
                              ? 'border-slate-700 bg-slate-900/60 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400' 
                              : 'border-slate-200 bg-slate-50/50 text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                        } transition-all duration-200`}
                      />
                    </div>
                    {errors.date && <p className="mt-1 text-xs text-red-500 font-medium">{errors.date}</p>}
                  </div>

                  {/* Preferred Slot */}
                  <div>
                    <label className={`block text-xs font-semibold uppercase tracking-wider mb-2 ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>
                      Preferred Time Slot
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Clock size={16} className={darkTheme ? 'text-slate-400' : 'text-slate-400'} />
                      </div>
                      <select
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        className={`block w-full pl-10 pr-3 py-3 text-sm rounded-xl outline-hidden border ${
                          darkTheme 
                            ? 'border-slate-700 bg-slate-900 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400' 
                            : 'border-slate-200 bg-white text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                        } transition-all duration-200`}
                      >
                        {AVAILABLE_TIMES.map(time => (
                          <option key={time} value={time}>{time}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Message (Symptoms Overview) */}
                <div>
                  <label className={`block text-xs font-semibold uppercase tracking-wider mb-2 ${darkTheme ? 'text-slate-300' : 'text-slate-700'}`}>
                    Primary Symptoms or Medical Background (Optional)
                  </label>
                  <div className="relative">
                    <div className="absolute top-3 left-3 pointer-events-none">
                      <FileText size={16} className={darkTheme ? 'text-slate-400' : 'text-slate-400'} />
                    </div>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={3}
                      placeholder="Describe symptoms, current medication profiles, or history brief..."
                      className={`block w-full pl-10 pr-3 py-3 text-sm rounded-xl outline-hidden border ${
                        darkTheme 
                          ? 'border-slate-700 bg-slate-900/60 text-white focus:border-teal-400 focus:ring-1 focus:ring-teal-400' 
                          : 'border-slate-200 bg-slate-50/50 text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600'
                      } transition-all duration-200`}
                    />
                  </div>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 py-4 bg-teal-600 hover:bg-teal-500 text-white font-semibold text-sm rounded-xl transition-all duration-300 cursor-pointer shadow-lg hover:shadow-teal-900/20 active:translate-y-0.5 group disabled:opacity-75 disabled:cursor-wait"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <span className="h-4 w-4 rounded-full border-2 border-t-transparent border-white animate-spin"></span>
                      Registering Clinical Clearance...
                    </span>
                  ) : (
                    <>
                      Confirm Clinical Booking
                      <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          ) : (
            <motion.div
              key="booking-success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="text-center py-6"
            >
              <div className="mx-auto h-16 w-16 bg-teal-500/10 text-teal-400 rounded-full flex items-center justify-center mb-4">
                <CheckCircle size={36} className="text-teal-500" />
              </div>
              <h3 className={`text-2xl font-bold tracking-tight mb-2 ${darkTheme ? 'text-white' : 'text-slate-900'}`}>
                Booking Confirmed
              </h3>
              <p className={`text-sm mb-6 max-w-md mx-auto ${darkTheme ? 'text-slate-300' : 'text-slate-500'}`}>
                Your executive consultation index has been created successfully. A clinical liaison will call you shortly to confirm coordinates.
              </p>

              {lastAppointment && (
                <div className={`p-5 rounded-2xl text-left max-w-sm mx-auto mb-6 border ${
                  darkTheme ? 'bg-slate-900/80 border-slate-700/60' : 'bg-slate-50 border-slate-100'
                }`}>
                  <p className="text-xs uppercase font-extrabold tracking-wider text-teal-500 mb-3 select-none">
                    Clinic Slip ID: {lastAppointment.id}
                  </p>
                  <div className="space-y-2 text-xs">
                    <p className={darkTheme ? 'text-slate-300' : 'text-slate-700'}>
                      <strong className={darkTheme ? 'text-white' : 'text-slate-900'}>Patient:</strong> {lastAppointment.name}
                    </p>
                    <p className={darkTheme ? 'text-slate-300' : 'text-slate-700'}>
                      <strong className={darkTheme ? 'text-white' : 'text-slate-900'}>Consultation:</strong> {lastAppointment.type}
                    </p>
                    <p className={darkTheme ? 'text-slate-300' : 'text-slate-700'}>
                      <strong className={darkTheme ? 'text-white' : 'text-slate-900'}>Date:</strong> {lastAppointment.date} ({lastAppointment.time})
                    </p>
                    <p className={darkTheme ? 'text-slate-300' : 'text-slate-700'}>
                      <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400">
                        Status: Digital Confirm
                      </span>
                    </p>
                  </div>
                </div>
              )}

              <button
                onClick={() => setShowSuccess(false)}
                className="px-6 py-2.5 border border-teal-500/30 hover:border-teal-500 text-teal-400 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Schedule Another Consultation
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Real-time booked history block */}
        {recentBookings.length > 0 && (
          <div className="mt-8 pt-6 border-t border-slate-700/30">
            <h4 className={`text-xs font-bold uppercase tracking-widest mb-4 ${darkTheme ? 'text-slate-400' : 'text-slate-600'}`}>
              Your Consultation History ({recentBookings.length})
            </h4>
            <div className="max-h-48 overflow-y-auto space-y-3 pr-2 scrollbar-thin">
              {recentBookings.map((b) => (
                <div 
                  key={b.id} 
                  className={`p-3 rounded-xl flex items-center justify-between text-xs border ${
                    darkTheme ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-50 border-slate-100'
                  }`}
                >
                  <div>
                    <p className={`font-semibold ${darkTheme ? 'text-slate-200' : 'text-slate-800'}`}>{b.type.split(" (")[0]}</p>
                    <p className={darkTheme ? 'text-slate-400' : 'text-slate-500'}>
                      {b.date} • {b.time.split(" -")[0]}
                    </p>
                    <p className="text-[10px] text-teal-400 mt-0.5 font-mono">{b.id}</p>
                  </div>
                  <button 
                    onClick={() => deleteBooking(b.id)}
                    className={`p-1.5 rounded-lg hover:text-red-400 transition-colors cursor-pointer ${
                      darkTheme ? 'text-slate-500 hover:bg-slate-800' : 'text-slate-400 hover:bg-slate-200'
                    }`}
                    title="Remove booking slip"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
